import { GetStartedButton } from "@/components/ui/get-started-button";

export function GetStartedButtonDemo() {
  return <GetStartedButton />
}
